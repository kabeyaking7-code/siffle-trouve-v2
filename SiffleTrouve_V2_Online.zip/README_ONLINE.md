# Siffle & Trouve V2 — Compilation en ligne

Cette version est préparée pour GitHub Actions.

## Méthode recommandée depuis un téléphone

1. Crée un compte GitHub.
2. Crée un nouveau dépôt, par exemple `SiffleTrouveV2`.
3. Téléverse tout le contenu de ce dossier dans le dépôt.
4. Ouvre l'onglet **Actions**.
5. Sélectionne **Build Android APK**.
6. Lance **Run workflow**.
7. Attends la fin du build.
8. Ouvre le résultat **SiffleTrouve-debug-apk** et récupère `app-debug.apk`.
9. Installe l'APK sur ton téléphone.

## Fonctionnalités V2
- Détection de sifflement.
- Service foreground pour continuer la détection avec l'écran éteint dans les limites d'Android.
- Notification indiquant que la protection est active.
- Alarme sonore.
- Vibration.
- Réglage de sensibilité dans l'interface.

## Limites
La détection est heuristique (niveau sonore + fréquence). Certains sons aigus peuvent déclencher l'alarme. Une future V3 peut utiliser une analyse FFT et une calibration personnalisée.

Le bouton de sensibilité de cette V2 est conservé dans l'interface ; le service utilise une valeur par défaut pour la stabilité du prototype.
