package com.siffletrouve

import android.media.*
import kotlin.math.*

class WhistleDetector(private val onWhistle: () -> Unit) {
    private var running = false
    private var recorder: AudioRecord? = null
    private var thread: Thread? = null
    private var lastTrigger = 0L

    fun start(sensitivity: Float) {
        if (running) return
        val rate = 44100
        val min = AudioRecord.getMinBufferSize(
            rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (min <= 0) return

        recorder = AudioRecord(
            MediaRecorder.AudioSource.MIC, rate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT, min * 2
        )

        running = true
        recorder!!.startRecording()

        thread = Thread {
            val buffer = ShortArray(min)
            while (running) {
                val n = recorder?.read(buffer, 0, buffer.size) ?: 0
                if (n > 0 && isWhistle(buffer, n, sensitivity)) {
                    val now = System.currentTimeMillis()
                    if (now - lastTrigger > 3000) {
                        lastTrigger = now
                        onWhistle()
                    }
                }
            }
        }.also { it.start() }
    }

    fun stop() {
        running = false
        try { recorder?.stop() } catch (_: Exception) {}
        recorder?.release()
        recorder = null
        thread = null
    }

    private fun isWhistle(x: ShortArray, n: Int, sensitivity: Float): Boolean {
        var sum = 0.0
        for (i in 0 until n) sum += x[i].toDouble() * x[i]
        val rms = sqrt(sum / n)

        val threshold = 700 + (1f - sensitivity) * 1800
        if (rms < threshold) return false

        var crossings = 0
        for (i in 1 until n) {
            if ((x[i - 1] < 0 && x[i] >= 0) ||
                (x[i - 1] >= 0 && x[i] < 0)) crossings++
        }

        val frequency = crossings * 44100.0 / (2.0 * n)

        // Bande approximative d'un sifflement humain.
        return frequency in 1200.0..4500.0
    }
}
