package com.siffletrouve

import android.app.*
import android.content.*
import android.media.*
import android.os.*
import androidx.core.app.NotificationCompat

class WhistleService : Service() {
    private lateinit var detector: WhistleDetector
    private var tone: ToneGenerator? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()

        val notification = NotificationCompat.Builder(this, "whistle")
            .setContentTitle("Siffle & Trouve")
            .setContentText("Détection de sifflement active")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()

        startForeground(1001, notification)

        detector = WhistleDetector { alarm() }
        detector.start(0.65f)
    }

    private fun alarm() {
        tone?.release()
        tone = ToneGenerator(AudioManager.STREAM_ALARM, 100)
        tone?.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 3000)

        val vibrator = if (Build.VERSION.SDK_INT >= 31) {
            getSystemService(VibratorManager::class.java).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }

        vibrator.vibrate(
            VibrationEffect.createWaveform(
                longArrayOf(0, 400, 150, 400, 150, 700),
                -1
            )
        )
    }

    override fun onDestroy() {
        detector.stop()
        tone?.release()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                "whistle",
                "Détection de sifflement",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }
}
