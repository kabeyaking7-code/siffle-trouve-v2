package com.siffletrouve

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        permissionLauncher.launch(
            arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.POST_NOTIFICATIONS
            )
        )

        setContent {
            MaterialTheme {
                var active by remember { mutableStateOf(false) }
                var sensitivity by remember { mutableFloatStateOf(0.65f) }

                Surface(Modifier.fillMaxSize()) {
                    Column(
                        Modifier.fillMaxSize().padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Spacer(Modifier.height(45.dp))
                        Text("Siffle & Trouve", style = MaterialTheme.typography.headlineLarge)
                        Spacer(Modifier.height(10.dp))
                        Text(
                            if (active) "🟢 Protection active"
                            else "⚪ Protection inactive"
                        )

                        Spacer(Modifier.height(40.dp))

                        Button(
                            onClick = {
                                if (active) {
                                    stopService(Intent(this@MainActivity, WhistleService::class.java))
                                } else {
                                    if (ContextCompat.checkSelfPermission(
                                            this@MainActivity,
                                            Manifest.permission.RECORD_AUDIO
                                        ) == PackageManager.PERMISSION_GRANTED
                                    ) {
                                        ContextCompat.startForegroundService(
                                            this@MainActivity,
                                            Intent(this@MainActivity, WhistleService::class.java)
                                        )
                                    }
                                }
                                active = !active
                            },
                            modifier = Modifier.fillMaxWidth().height(60.dp)
                        ) {
                            Text(if (active) "ARRÊTER" else "ACTIVER LA RECHERCHE")
                        }

                        Spacer(Modifier.height(30.dp))

                        Text("Sensibilité : ${(sensitivity * 100).toInt()}%")
                        Slider(
                            value = sensitivity,
                            onValueChange = { sensitivity = it },
                            valueRange = 0.1f..1f
                        )

                        Spacer(Modifier.height(20.dp))

                        Text(
                            "Pose ton téléphone, active la protection puis siffle. " +
                            "La détection reste active via un service Android."
                        )
                    }
                }
            }
        }
    }
}
